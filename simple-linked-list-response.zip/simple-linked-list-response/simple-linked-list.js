//
// This is only a SKELETON file for the 'Simple Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Element {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

export class List {
  constructor(array = []) {
    var head = null;
    array.forEach(function(value){
      head = new Element(value, head);
    });
    this.head = head;
  }

  add(nextElement) {
    // Add a new element with the value suplied and the next as the current head
    nextElement.next = this.head
    this.head = nextElement;
  }

  get length() {
    // store the head for resetting
    var head = this.head;
    // Increment a value by 1 for each element
    var length = 0;
    while(this.head != null)
    {
      length++;
      this.head = this.head.next;
    }
    // Reset the Listnpm 
    this.head = head;
    // Return the length
    return length;
  }

  toArray() {
    // store the head for resetting
    var head = this.head;
    // Add each value to an array
    var array = [];
    while(this.head != null)
    {
      array.push(this.head.value);
      this.head = this.head.next;
    }
    // Reset the List
    this.head = head;
    // Return the length
    return array;
  }

  reverse(){
    // Store a tracker the previous element in the list
    var prev = null;
    // Loop through all the elements
    while(this.head != null)
    {
      // Store the next value as we will be changing this but still want to know what it is
      var next = this.head.next;
      // Assign this elements next to the previous element
      this.head.next = prev;
      // Assign the previous element tracker to this element for the next loop
      prev = this.head;
      // Continue on to what was originally the next element in the list
      this.head = next;
    }
    // Go back to the last element
    this.head = prev;
    return this;
  }
}
